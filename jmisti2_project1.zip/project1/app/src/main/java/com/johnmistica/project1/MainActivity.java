/**
 * CS478 Project 1 Spring 2021
 * Author: John Mistica
 * UIN: 660678902
 * netid: jmisti2
 *
 * Description: This application showcases basic functionality of widgets, activites, and processes.
 * This application has two activites. The main one prompts the user to select one of two buttons.
 * Button 1 asks the user to enter a valid legal name. If name given is valid, user is able to click Button 2
 * which leads the user to the edit contacts field to which is populated by the user inputted legal name.
 * If name is invalid the activity terminates and returns a result code of "RESULT CANCELED" and prompts
 * the user with a toast stating that their input was invalid
 *
 */

package com.johnmistica.project1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.widget.Button;
import android.view.View;
import android.content.Intent;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //Variables bound to GUI widgets
    protected Button but1;
    protected Button but2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        but1 = (Button) findViewById(R.id.button);
        but2 = (Button) findViewById(R.id.button2);

        but1.setOnClickListener(but1listener);


    }

    //listener for button 1 which switches to activity 2
    public View.OnClickListener but1listener = v -> switchToActivity2();

    //listener for button 2 which switches to edit contacts activity
    public View.OnClickListener but2listener = v -> switchToEditContact();

    //declares new intent to switch to activity2
    private void switchToActivity2() {
        Intent i = new Intent(MainActivity.this,Activity2.class);
        startActivityForResult(i, 99);
    }

    //declares new intent to switch to edit contact activity
    //fills in data from activity2 (full legal name) into the edit contact activities fields
    private void switchToEditContact(){
        Intent intent = new Intent(ContactsContract.Intents.Insert.ACTION);
        intent.setType(ContactsContract.RawContacts.CONTENT_TYPE);
        intent.putExtra(ContactsContract.Intents.Insert.NAME, Activity2.firstName + " " + Activity2.middleName + " " + Activity2.lastName);
        startActivity(intent);

    }

    protected void onActivityResult(int code, int result_code, Intent i) {
        super.onActivityResult(code, result_code, i);
        if(result_code == -1){//if entry from activity2 was valid attaches but2listener
            but2.setOnClickListener(but2listener);
        }
        else{//otherwise prompts user with toast when button 2 is clicked
            but2.setOnClickListener(v -> Toast.makeText(MainActivity.this, Activity2.textInput.getText().toString().trim() + " is an invalid name", Toast.LENGTH_LONG).show());
        }
        Log.i("MainActivity: ", "Returned result is: " + result_code) ;

    }



}