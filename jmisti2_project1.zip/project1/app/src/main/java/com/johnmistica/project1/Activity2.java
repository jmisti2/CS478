package com.johnmistica.project1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;

import com.google.android.material.textfield.TextInputLayout;

public class Activity2 extends AppCompatActivity {

    public static EditText textInput;
    public static String firstName = "";
    public static String middleName = "";
    public static String lastName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        textInput = findViewById(R.id.editTextName);

        //detects if user hits return or clicks confirm on soft keyboard
        textInput.setOnKeyListener((v, keyCode, event) -> {
            if(event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER){
                Log.i("Activity2: ", "input received");
                if(checkInput()){
                    setResult(RESULT_OK);
                }
                else{
                    setResult(RESULT_CANCELED);
                }
                finish();
                return true;
            }
            return false;
        });

    }

    //checks to see if a string is compromised entirely of alphabetical letters
    private boolean isAlpha(String name){
        return name.matches("[a-zA-Z]+");
    }

    //checks user input to see if they have entered a valid legal name
    private boolean checkInput(){
        int spaceCount = 0;

        //trims preceding and trailing white space from user input
        String inputName = textInput.getText().toString().trim();


        //detects number of names given by counting spaces
        for(int i = 0; i < inputName.length(); i++){
            if(inputName.charAt(i) == ' '){
                spaceCount++;
            }
        }

        //check if there is only 2 names
        if(spaceCount == 1){
            for(int i = 0; i < inputName.length(); i++){
                if(inputName.charAt(i) == ' '){
                    firstName = inputName.substring(0,i);
                    middleName = "";
                    lastName = inputName.substring(i+1,inputName.length());
                    if(firstName.length() >= 2 && lastName.length() >= 3 && isAlpha(firstName) && isAlpha(lastName)){
                        Log.i("CheckInput: ", firstName + lastName);
                        return true;
                    }
                }
            }
        }
        //check if there is a middle name
        else if(spaceCount == 2){
            for(int i = 0; i < inputName.length(); i++){
                if(inputName.charAt(i) == ' '){
                    firstName = inputName.substring(0,i);
                    inputName = inputName.substring(i+1,inputName.length());
                    for(int j = 0; j < inputName.length(); j++){
                        if(inputName.charAt(j) == ' ') {
                            middleName = inputName.substring(0,j);
                            lastName = inputName.substring(j+1,inputName.length());
                            if(firstName.length() >= 2 && middleName.length() >= 1 && lastName.length() >= 3 && isAlpha(firstName) && isAlpha(middleName) && isAlpha(lastName)){
                                Log.i("CheckInput: ", firstName + middleName + lastName);
                                return true;
                            }
                        }
                    }
                }
            }
        }

        Log.i("Error: ", "Invalid name entered");

        return false;
    }

}